"""
OSEF Graph Visualization Plugin
"""
